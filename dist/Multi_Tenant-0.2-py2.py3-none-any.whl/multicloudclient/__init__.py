#import py_compile
#py_compile.compile('__init__.py')
